# SMSMaster
[Концепция и основы](https://github.com/ProITAbkh/smsmaster/blob/main/docs/basics.md)

[Разворачивание проекта](https://github.com/ProITAbkh/smsmaster/blob/main/docs/deploy.md)

[API](https://github.com/ProITAbkh/smsmaster/blob/main/docs/api.md)

[Схема базы данных](https://github.com/ProITAbkh/smsmaster/blob/main/docs/db_schema.png)
> **_NOTE:_** При необходимости, есть возможность получить доступ к схеме базы данных на **dbdesigner.net**

> **_NOTE:_** Документация будет пополняться по мере разработки
