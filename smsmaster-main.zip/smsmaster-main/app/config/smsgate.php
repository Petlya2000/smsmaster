<?php

return [
    'base_url' => env('SMS_GATE_URL', '127.0.0.1:8001'),
];
