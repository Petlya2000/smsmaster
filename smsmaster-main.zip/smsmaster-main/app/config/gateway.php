<?php
return [
    'ip_whitelist' => [
        '172.24.6.4',
        '172.24.6.5',
        '172.19.0.1', '192.168.80.1'  // TODO: Remove before deploy on production
    ]
];
