<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('advertisement_tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('manager_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->integer('clients_target_count')->default(0);
            $table->integer('clients_handled_count')->default(0);
            $table->json('districts');
            $table->string('text')->nullable();
            $table->integer('seed');
            $table->foreignId('last_client_id')->constrained('advertisement_clients');
            $table->timestamps();
            $table->datetime('scheduled_to')->nullable();
            $table->boolean('ensure_delivery')->default(false);
            $table->string('status');
            $table->boolean('active')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('advertisement_tasks');
    }
};
