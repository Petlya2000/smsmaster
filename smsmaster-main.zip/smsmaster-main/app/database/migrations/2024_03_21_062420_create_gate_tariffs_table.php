<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('gate_tariffs', function (Blueprint $table) {
            $table->id();
            $table->boolean('track_message_state')->default(false);
            $table->integer('messages_per_minute')->default(10);
            $table->integer('repeated_send_per_minute')->default(1);
            $table->decimal('price_rub');
            $table->boolean('archived')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('gate_tariffs');
    }
};
