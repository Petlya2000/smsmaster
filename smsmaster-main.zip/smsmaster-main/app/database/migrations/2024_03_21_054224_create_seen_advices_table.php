<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('seen_advices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('client_id')->constrained('advice_clients')->cascadeOnDelete();
            $table->foreignId('advice_id')->constrained('advices')->cascadeOnDelete();
            $table->string('message_id')->nullable();
            $table->boolean('approved')->default(false);
            $table->dateTime('seen_at')->nullable();
            $table->dateTime('expires_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('seen_advices');
    }
};
