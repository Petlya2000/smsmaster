<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('configuration', function (Blueprint $table) {
            $table->boolean('advice_distribution_running')->default(false);
            $table->json('advice_distribution_time_range');
            $table->integer('advice_distribution_interval')->default(10800);
            $table->integer('delivery_attempts')->default(3);
        });

        DB::table('configuration')->insert([
            'advice_distribution_time_range' => '["09:00", "18:00"]'
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('configuration');
    }
};
