<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\AdvertisementClient>
 */
class AdvertisementClientFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'manager_id' => $this->attributes['manager_id'] ?? 1,
            'phoneNumber' => fake()->randomNumber(9, true),
            'district_id' => $this->attributes['district_id'] ?? 1
        ];
    }
}
