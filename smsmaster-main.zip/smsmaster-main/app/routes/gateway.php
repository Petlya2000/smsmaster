<?php

use App\Http\Controllers\AdvertisementClientController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdviceClientController;




Route::prefix('phone')->group(function (){
    Route::controller(AdviceClientController::class)->group(function () {
        Route::put('{phoneNumber}', 'store');
        Route::delete('{phoneNumber}', 'disable');
        Route::get('add/{phoneNumber}', 'store');
        Route::get('remove/{phoneNumber}', 'disable');
    });
});

Route::prefix('advertisements/phone')->group(function (){
    Route::controller(AdvertisementClientController::class)->group(function () {
        Route::get('remove/{phoneNumber}', 'disable');
        Route::delete('{phoneNumber}', 'disable');
    });
});
