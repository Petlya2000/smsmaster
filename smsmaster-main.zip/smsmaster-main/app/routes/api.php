<?php

use App\Http\Controllers\ActivityLogController;
use App\Http\Controllers\AdvertisementClientController;
use App\Http\Controllers\AdviceClientController;
use App\Http\Controllers\AdviceController;
use App\Models\District;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('advices')->group(function (){
    Route::controller(AdviceController::class)->group(function () {
        Route::get('', 'index');
        Route::post('create', 'store');
        Route::post('{id}/edit', 'edit');
        Route::delete('{id}', 'delete');
    });
});

Route::prefix('advices/clients')->group(function (){
    Route::controller(AdviceClientController::class)->group(function () {
        Route::get('', 'index');
//        Route::get('{phoneNumber}/', 'index');
    });
});

Route::prefix('advertisements')->group(function (){
    Route::controller(AdvertisementClientController::class)->group(function () {
        Route::get('clients', 'index');
        Route::post('clients/import', 'import');
    });
});

Route::get('districts', function (){
    return District::all();
});

Route::prefix('admin/logs')->group(function (){
    Route::controller(ActivityLogController::class)->group(function () {
        Route::get('', 'index');
    });
});
