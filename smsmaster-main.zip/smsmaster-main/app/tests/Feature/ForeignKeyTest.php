<?php

namespace Tests\Feature;

use App\Models\AdvertisementClient;
use App\Models\District;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ForeignKeyTest extends TestCase
{
    use RefreshDatabase;
    public function test(): void
    {
        $user = User::factory()->create();
        $this->assertModelExists($user);
        $district = District::factory()->create();
        $this->assertModelExists($district);
        $client = AdvertisementClient::factory()->create(['manager_id' => $user->id, 'district_id' => $district->id]);
        $this->assertModelExists($client);
        $district->delete();
        $this->assertModelMissing($district);
        $this->assertNotNull($client->district_id);
        $client->refresh();
        $this->assertNull($client->district_id);

    }
}
