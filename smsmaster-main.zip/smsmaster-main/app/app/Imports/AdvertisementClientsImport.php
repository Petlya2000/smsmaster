<?php

namespace App\Imports;

use App\Models\AdvertisementClient;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Events\AfterImport;
use Maatwebsite\Excel\Sheet;
use Maatwebsite\Excel\Validators\Failure;
use Throwable;

/**
 * @method import(string $getFilename, $null, string $CSV)
 */
class AdvertisementClientsImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */

    public int $fetched = 0;
    public int $skipped = 0;
    public array $validationErrors = [];

    use Importable;
    public function model(array $row)
    {
        $phoneLength = strlen($row[0]);
        $tmpPhone = $row[0];
        if ($phoneLength < 7 || $phoneLength > 11) return null;
        if ($phoneLength == 7) $tmpPhone = '7940' . $row[0];
        $rows = [
            'phone_number' => (int)$tmpPhone,
            'manager_id' => 1,
            'district_id' => $row[1]
        ];
        $validator = Validator::make($rows, [
            'phone_number' => 'bail|unique:advertisement_clients',
        ]);
        if ($validator->fails()) {
            $this->skipped += 1;
            return null;
        };
        $this->fetched += 1;
        return new AdvertisementClient($rows);
    }

            //    public function customValidationMessages(): array
            //    {
            //        return [
            //            'phone_number.unique' => 'already_used'
            //        ];
            //    }
            //    public function rules(): array
            //    {
            //        return [
            //            '0' => [Rule::unique('advertisement_clients', 'phone_number')],
            ////            '0' => [
            ////                Rule::unique('advertisement_clients', 'phone_number'),
            ////                function ($attribute, $value, $fail) {
            ////                    echo "validating `$attribute`...\n";
            ////                    if (!(mb_strlen($value) == 7 || mb_strlen($value) == 11))
            ////                    {
            ////                        $fail('out_of_range');
            ////                    }
            ////                },
            ////            ],
            //        ];
            //    }

//    public function rules(): array
//    {
//        return [
//            '1' => Rule::in(range(0, 7)),
//        ];
//    }
    public function onFailure(Failure ...$failures)
    {
        $exception = ValidationException::withMessages(collect($failures)->map->toArray()->all());

        throw $exception;
    }
}
