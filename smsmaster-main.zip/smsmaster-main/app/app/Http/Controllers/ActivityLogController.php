<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $offset = $request->offset ?? 0;
        $limit = $request->limit ?? 10;
        $activityLogs = DB::table('activity_log')
            ->join('activity_types', 'activity_log.action_type', '=', 'activity_types.id')
            ->select('activity_log.id', 'manager_id', 'display_name as action_type', 'action_data', 'created_at')
            ->skip($offset)
            ->take($limit)
            ->get();
        return response()->json(['response' => $activityLogs, 'offset' => $offset, 'count' => count($activityLogs)]);
    }
}
