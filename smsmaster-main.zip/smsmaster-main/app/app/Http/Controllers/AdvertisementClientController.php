<?php

namespace App\Http\Controllers;

use App\Imports\AdvertisementClientsImport;
use App\Models\AdvertisementClient;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Excel;
use Illuminate\Validation\Rules\File;
class AdvertisementClientController extends Controller
{
    public function index(Request $request)
    {
        $offset = $request->offset ?? 0;
        $limit = $request->limit ?? 10;
        $advertisementClients = AdvertisementClient::whereActive(1)->get()->skip($offset)->take($limit);
        return response()->json(['response' => $advertisementClients, 'offset' => $offset, 'count' => count($advertisementClients)]);
    }

    public function import(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => [
                'required',
                File::types(['csv'])->min('1kb')->max('128mb')
            ]
        ],
        messages:
        [
            'file.required' => 'not_passed',
            'file.type' => 'file_mistype',
            'file.max' => 'out_of_range'
        ]);
        if ($validator->fails()) return response()->json(['error'=> $validator->errors()], 400);
        $file = $request->file('file');

        try {
            $import = new AdvertisementClientsImport();
            $import->import($file->getPath() . '/' . $file->getFilename(), null, Excel::CSV);
            ActivityLogService::write('ads_clients_import', 1, ['count' => $import->fetched + $import->skipped, 'fetched' => $import->fetched, 'skipped' => $import->skipped]);
//            dd($result);
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            $failures = $e->failures();

//            foreach ($failures as $failure) {
//                $failure->row(); // row that went wrong
//                $failure->attribute(); // either heading key (if using heading row concern) or column index
//                $failure->errors(); // Actual error messages from Laravel validator
//                $failure->values(); // The values of the row that has failed.
//            }
            return response()->json(['response' => $failures]);
        }
        return response()->json(['response' => 'ok']);
    }

    public function disable(int $phoneNumber)
    {
        $client = AdvertisementClient::wherePhoneNumber($phoneNumber)->first();
        // public method shouldn't compromise info about registered clients
        if (!$client) return response()->json(['response' => 'ok']); // return response()->json(['error' => 'client_not_found'], 404);
        $client->active = false;
        $client->save();
        return response()->json(['response' => 'ok']);
    }
}
