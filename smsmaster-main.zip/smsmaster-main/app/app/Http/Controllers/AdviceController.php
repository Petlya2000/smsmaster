<?php

namespace App\Http\Controllers;

use App\Exceptions\ActivityLogIllegalArgumentException;
use App\Exceptions\ActivityLogTypeNotFoundException;
use App\Models\Advice;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class AdviceController extends Controller
{
    public function index()
    {
        $advices = Advice::all();
        return response()->json(['response' => $advices]);
    }

    /**
     * @throws ActivityLogTypeNotFoundException
     * @throws ActivityLogIllegalArgumentException
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'text' => 'bail|required|unique:advices',
            'priority' => 'nullable|boolean',
            'attached_day' => 'nullable|integer|max:99',
            'active' => 'nullable|boolean'
        ],
        messages:
        [
            'text.required' => 'not_passed',
            'text.unique' => 'already_used',
            'attached_day.max' => 'out_of_range'
        ],
        );
        if ($validator->fails()) return response()->json(['error'=> $validator->errors()], 400);

        $advice = new Advice();
        $advice->text = $request->text;
        $advice->priority = $request->priority ?? 0;
        $advice->attached_day = $request->attached_day ?? null;
        $advice->active = $request->active ?? true;
        $advice->timestamps = false;
        $advice->save();
        ActivityLogService::write('advice_creation', 1, ['text' => $request->text]);
        return response()->json(['response'=> 'ok']);
    }
    public function edit(Request $request, int $id)
    {
        $validator = Validator::make($request->all(), [
            'text' => [
                Rule::unique('advices')->ignore($id)
            ],
            'priority' => 'nullable|integer|max:1',
            'attached_day' => 'nullable|integer|max:99',
            'active' => 'nullable|boolean'
        ]);
        if ($validator->fails()) return response()->json(['error'=> $validator->errors()], 400);

        $advice = Advice::findOrFail($id);
        $advice->update($request->all());

        return response()->json(['response'=> 'ok']);
    }

    public function delete(Request $request, int $id)
    {
        $advice = Advice::findOrFail($id);
        return response()->json(['response'=> ($advice->delete() ? 'ok' : 'fail')]);
    }
}
