<?php

namespace App\Http\Controllers;

use App\Models\AdviceClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AdviceClientController extends Controller
{
    public function index(Request $request)
    {
        $offset = $request->offset ?? 0;
        $limit = $request->limit ?? 10;
        $adviceClients = AdviceClient::all()->skip($offset)->take($limit);
        return response()->json(['response' => $adviceClients, 'offset' => $offset, 'count' => count($adviceClients)]);
    }
    public function store(Request $request, int $phoneNumber)
    {
        if (strlen($phoneNumber) != 11) response()->json(['error' => 'phone format invalid'], 400);
        $client = AdviceClient::wherePhoneNumber($phoneNumber)->first();
        if ($client)
        {
            DB::table('seen_advices')->where('client_id', '=', $client->id)->delete();
            $client->active = true;
            $client->save();
            return response()->json(['response' => 'ok']);
        }
        $client = new AdviceClient();
        $client->phone_number = $phoneNumber;
        $client->save();
        return response()->json(['response' => 'ok']);
    }

    public function disable(Request $request, int $phoneNumber)
    {
        $client = AdviceClient::wherePhoneNumber($phoneNumber)->first() ?? response()->json(['error' => 'client_not_found'], 404);
        $client->active = false;
        $client->save();
        return response()->json(['response' => 'ok']);
    }
}
