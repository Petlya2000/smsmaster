<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @property int $id
 * @property int $manager_id
 * @property string $title
 * @property int $clients_target_count
 * @property int $clients_handled_count
 * @property string $districts
 * @property string|null $text
 * @property int $seed
 * @property int $last_client_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $scheduled_to
 * @property int $ensure_delivery
 * @property string $status
 * @property int $active
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask query()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereClientsHandledCount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereClientsTargetCount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereDistricts($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereEnsureDelivery($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereLastClientId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereManagerId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereScheduledTo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereSeed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereText($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementTask whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class AdvertisementTask extends Model
{
    use HasFactory;
}
