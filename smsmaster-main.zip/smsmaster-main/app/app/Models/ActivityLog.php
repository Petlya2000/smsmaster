<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog query()
 * @property int $id
 * @property int $manager_id
 * @property int $action_type
 * @property string $action_data
 * @property \Illuminate\Support\Carbon $created_at
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog whereActionData($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog whereActionType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityLog whereManagerId($value)
 * @mixin \Eloquent
 */
class ActivityLog extends Model
{
    use HasFactory;
    protected $table = 'activity_log';
    const UPDATED_AT = null;

    protected $casts = [
        'action_data' => 'array',
    ];
}
