<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @property int $id
 * @property int $client_id
 * @property int $advice_id
 * @property string $message_id
 * @property int $approved
 * @property string|null $seen_at
 * @property string|null $expires_at
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice query()
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereAdviceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereClientId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereExpiresAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereMessageId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SeenAdvice whereSeenAt($value)
 * @mixin \Eloquent
 */
class SeenAdvice extends Model
{
    use HasFactory;
    protected $table = 'seen_advices';
}
