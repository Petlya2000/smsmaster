<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 *
 *
 * @property int $id
 * @property int $manager_id
 * @property int $phoneNumber
 * @property int|null $district_id
 * @property int $active
 * @method static \Database\Factories\AdvertisementClientFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient query()
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient whereActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient whereDistrictId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient whereManagerId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdvertisementClient wherePhoneNumber($value)
 * @mixin \Eloquent
 */
class AdvertisementClient extends Model
{
    use HasFactory;
    public $timestamps = false;

    protected $fillable = [
        'phone_number',
        'district_id',
        'manager_id',
        'active'
    ];

}
