<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @method static \Illuminate\Database\Eloquent\Builder|GateBilling newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateBilling newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateBilling query()
 * @mixin \Eloquent
 */
class GateBilling extends Model
{
    use HasFactory;
}
