<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 *
 *
 * @property int $id
 * @property string $display_name
 * @property string $template
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType query()
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType whereDisplayName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActivityType whereTemplate($value)
 * @mixin \Eloquent
 */
class ActivityType extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $casts = [
        'template' => 'array',
    ];
}
