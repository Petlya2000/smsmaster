<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @property int $id
 * @property int $track_message_state
 * @property int $messages_per_minute
 * @property int $repeated_send_per_minute
 * @property string $price_rub
 * @property int $archived
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff query()
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff whereArchived($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff whereMessagesPerMinute($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff wherePriceRub($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff whereRepeatedSendPerMinute($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateTariff whereTrackMessageState($value)
 * @mixin \Eloquent
 */
class GateTariff extends Model
{
    use HasFactory;
}
