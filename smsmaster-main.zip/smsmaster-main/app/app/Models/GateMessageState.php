<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @property int $id
 * @property int $manager_id
 * @property string|null $message_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $message_state
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState query()
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereManagerId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereMessageId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereMessageState($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GateMessageState whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class GateMessageState extends Model
{
    use HasFactory;
}
