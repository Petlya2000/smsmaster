<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 *
 *
 * @property int $id
 * @property int $phone_number
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $active
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient query()
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient whereActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient wherePhoneNumber($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AdviceClient whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class AdviceClient extends Model
{
    use HasFactory;

    public function seeAdvice(int $adviceId): bool
    {
        $seenAdvice = new SeenAdvice();
        $seenAdvice->advice_id = $adviceId;
        $seenAdvice->client_id = self::$id;
        $seenAdvice->save();
        return true;
    }

    public function approveAdviceDelivery(String $messageId): bool
    {
        if ($seenAdvice = SeenAdvice::whereMessageId($messageId)->first())
        {
            $seenAdvice->approved = true;
            $seenAdvice->save();
            return true;
        }
        return false;
    }
}
