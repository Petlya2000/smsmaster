<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * 
 *
 * @method static \Illuminate\Database\Eloquent\Builder|Advice newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Advice newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Advice query()
 * @property int $id
 * @property string $text
 * @property int $priority
 * @property int|null $attached_day
 * @property int $active
 * @method static \Illuminate\Database\Eloquent\Builder|Advice whereActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Advice whereAttachedDay($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Advice whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Advice wherePriority($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Advice whereText($value)
 * @method static findOrFail(int $id)
 * @mixin \Eloquent
 */
class Advice extends Model
{
    use HasFactory;
    protected $table = 'advices';
    public $timestamps = false;
    protected $fillable = [
        'text',
        'priority',
        'attached_day',
        'active'
    ];

}
