<?php

namespace App\Permissions;

class Roles
{

}
