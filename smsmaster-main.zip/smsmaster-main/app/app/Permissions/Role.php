<?php

namespace App\Permissions;

class Role
{
    protected array $permissions = [];

    public function addPermission(String $name): void
    {
        $this->permissions[] = $name;
    }

    public function addPermissions(array $permissions): void
    {
        $this->permissions = array_merge($this->permissions, $permissions);
    }
    public function can(String $name): bool
    {
        return in_array($name, $this->permissions);
    }
}
