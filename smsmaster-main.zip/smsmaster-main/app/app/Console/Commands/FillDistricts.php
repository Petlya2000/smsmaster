<?php

namespace App\Console\Commands;

use App\Models\District;
use Illuminate\Console\Command;

class FillDistricts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fill-districts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (District::all()->count() == 0)
        {
            for ($i = 0; $i < 7; $i++)
            {
                $district = new District();
                $district->display_name = fake()->city();
                $district->save();
            }
            echo "OK!\n";
        }
        else
        {
            echo "Already filled\n";
        }
    }
}
