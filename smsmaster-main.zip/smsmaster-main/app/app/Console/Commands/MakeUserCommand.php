<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class MakeUserCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:make-user';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Make root user';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!User::find(1))
        {
            $user = new User();
            $user->password = Hash::make('password');
            $user->login = 'system';
            $user->fullname = 'system';
            $user->role = 'su';
            $user->remember_token = Str::random(10);
            $user->save();
            return 0;
        }
        return -1;
    }
}
