<?php

namespace App\Console\Commands;

use App\Models\ActivityType;
use Illuminate\Console\Command;

class FillActivityTemplates extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fill-activity-templates';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {

        if (ActivityType::all()->count() == 0)
        {
            $activity = new ActivityType();
            $activity->display_name = 'advice_creation';
            $activity->template = '{"text": ""}';
            $activity->save();

            $activity = new ActivityType();
            $activity->display_name = 'ads_clients_import';
            $activity->template = '{"count": "", "fetched": "", "skipped": ""}';
            $activity->save();

            echo "Ok!\n";
        }
        else
        {
            echo "Already filled\n";
        }

    }
}
