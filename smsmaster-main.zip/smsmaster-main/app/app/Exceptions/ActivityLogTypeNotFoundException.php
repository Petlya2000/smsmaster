<?php

namespace App\Exceptions;

use Exception;

class ActivityLogTypeNotFoundException extends Exception
{
    protected $message = 'Activity log type not exists';
}
