<?php

namespace App\Exceptions;

use Exception;

class ActivityLogIllegalArgumentException extends Exception
{
    protected $message = 'ActivityLogService type has not includes passed argument';
}
