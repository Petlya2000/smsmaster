<?php

namespace App\Services;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

class SmsGateService
{
    public static function send(int $phoneNumber, String $sender, String $text): String|null
    {
        try {
            $result = (new Client())->post(config('smsgate.base_url') . "/submit?s=$sender&d=$phoneNumber&rd=1", ['body' => $text]);
            if ($result->getStatusCode() != 200)
            {
                Log::error("Error while sending text `$text` on phone number `$phoneNumber` as $sender [http error]");
            }
            return $result->getBody();

        } catch (GuzzleException $e) {
            Log::error("Error while sending text `$text` on phone number `$phoneNumber` as $sender [exception]");
            return null;
        }
    }
}
