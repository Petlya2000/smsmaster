<?php

namespace App\Services;

use App\Exceptions\ActivityLogIllegalArgumentException;
use App\Exceptions\ActivityLogTypeNotFoundException;
use App\Models\ActivityLog;
use App\Models\ActivityType;

class ActivityLogService
{
    public static function write(String $activityType, int $managerId, array $activityDetails)
    {
        $activityLogModel = ActivityType::whereDisplayName($activityType)->first() ?? throw new ActivityLogTypeNotFoundException();
        $activityTypeTemplate = $activityLogModel->template;
        if (array_diff_key($activityTypeTemplate, $activityDetails)) throw new ActivityLogIllegalArgumentException();
        $activityLog = new ActivityLog();
        $activityLog->action_type = $activityLogModel->id;
        $activityLog->manager_id = $managerId;
        $activityLog->action_data = array_combine(array_keys($activityTypeTemplate), $activityDetails);
        $activityLog->save();
        return true;
    }
}
