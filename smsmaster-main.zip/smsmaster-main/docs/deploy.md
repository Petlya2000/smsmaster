
## Разворачивание проекта
Для начала необходимо скопировать проект при помощи git clone из рабочего репозитория

На рабочей машине необходимо наличие docker и docker-compose.

> **Warning**
> При использовании Windows, как рабочей среды, переносить файлы проекта в среду WSL, в противном случае время ответа до любого эндпоинта кратно увеличится.

Откройте папку с проектом, создайте и настройте .env файл используя пример из .env.example

> **Warning** При разворачивании в среде Linux сначала необходимо переключить контекст командой:
```bash
  docker context use default 
```
Выполните команду для сборки образов контейнеров:
```bash
  docker-compose build 
```
Затем для запуска контейнеров:
```bash
  docker-compose up
```
Или для работы в фоновом режиме:
```bash
  docker-compose up -d
```

Далее нужно получить доступ к терминалу контейнера **smsmaster-app**, в котором находится само приложение и composer.
Получаем список контейнеров:
```bash
  docker ps
```
(упрощённый пример вывода)
```
CONTAINER ID   NAMES
71f7fdba9c87   smsmaster-webserver
5c5328adfb35   smsmaster-app
efb5af7258a9   smsmaster-mariadb
```
Берём ID контейнера и подключаемся к нему:
(пример)
```bash
  docker exec -it 5c5328adfb35 bash
```
После этого мы окажемся внутри контейнера.
Нужно перейти из папки `app/` на одну директорию выше с помощью команды `cd ../`

Далее подтягиваем зависимости:
```bash
  composer install
```

Делаем миграции:
```bash
  php artisan migrate
```
И выполняем несколько встроенных команд
```bash
  php artisan app:app:make-user
```
```bash
  php artisan app:fill-activity-templates
```
```bash
  php artisan app:fill-districts
```

Проект развёрнут и должен функционировать корректно.
